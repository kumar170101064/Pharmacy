﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class check
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chec = New System.Windows.Forms.Button()
        Me.input = New System.Windows.Forms.TextBox()
        Me.id = New System.Windows.Forms.TextBox()
        Me.pick = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'chec
        '
        Me.chec.Location = New System.Drawing.Point(302, 211)
        Me.chec.Name = "chec"
        Me.chec.Size = New System.Drawing.Size(164, 31)
        Me.chec.TabIndex = 0
        Me.chec.Text = "check"
        Me.chec.UseVisualStyleBackColor = True
        '
        'input
        '
        Me.input.Location = New System.Drawing.Point(426, 84)
        Me.input.Name = "input"
        Me.input.Size = New System.Drawing.Size(203, 22)
        Me.input.TabIndex = 1
        '
        'id
        '
        Me.id.Location = New System.Drawing.Point(426, 37)
        Me.id.Name = "id"
        Me.id.Size = New System.Drawing.Size(126, 22)
        Me.id.TabIndex = 2
        '
        'pick
        '
        Me.pick.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.pick.Location = New System.Drawing.Point(426, 141)
        Me.pick.Name = "pick"
        Me.pick.Size = New System.Drawing.Size(177, 22)
        Me.pick.TabIndex = 3
        Me.pick.Value = New Date(2019, 2, 5, 0, 0, 0, 0)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(332, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Eid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(264, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Medicine Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(276, 141)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Expire Before"
        '
        'check
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(986, 364)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pick)
        Me.Controls.Add(Me.id)
        Me.Controls.Add(Me.input)
        Me.Controls.Add(Me.chec)
        Me.Name = "check"
        Me.Text = "check"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chec As System.Windows.Forms.Button
    Friend WithEvents input As System.Windows.Forms.TextBox
    Friend WithEvents id As System.Windows.Forms.TextBox
    Friend WithEvents pick As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
