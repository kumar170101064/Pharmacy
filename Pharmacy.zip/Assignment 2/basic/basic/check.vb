﻿Imports System.Data.OleDb


Public Class check
    Dim provider As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
    Dim datafile As String = "C:\Users\DELL\Desktop\data.accdb"
    Dim Connstring As String = provider & datafile
    Dim connection As OleDbConnection = New OleDbConnection

    Private Sub chec_Click(sender As Object, e As EventArgs) Handles chec.Click

        Dim idd As String = id.Text()
        Dim i As Integer = 0
        If Not (Len(idd) = 7) Then
            If MessageBox.Show("Eid is not Properly Defined", "Eid Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Cancel Then
                Me.Close()
            Else
                id.Text() = ""
                Exit Sub
            End If
            Exit Sub
        End If



        For i = 0 To Len(idd) - 1

            If i < 3 And (Asc(idd(i)) < Asc("a") Or Asc("z") < Asc(idd(i))) Then
                If MessageBox.Show("Eid should contain 3 name characters", "Eid Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Cancel Then
                    Me.Close()
                    Exit Sub
                Else
                    id.Text = ""
                    Exit Sub
                End If
            End If
            If i > 2 And (Asc(idd(i)) > Asc("9") Or Asc("0") > Asc(idd(i))) Then
                If MessageBox.Show("Eid should contain last 4 number characters", "Inappropriate Primary value", MessageBoxButtons.RetryCancel, MessageBoxIcon.Asterisk) = Windows.Forms.DialogResult.Cancel Then
                    Me.Close()
                    Exit Sub
                Else
                    id.Text() = ""
                    Exit Sub
                End If
            End If

        Next














        connection.ConnectionString = Connstring
        connection.Open()

        Dim count As Integer = 0

        Dim cmd As OleDbCommand = New OleDbCommand

        Dim cmmd As OleDbCommand = New OleDbCommand

        cmd.CommandText = "Select COUNT(*) FROM medicines where     name= '" & input.Text() & "' And Eid = '" & id.Text() & "'  "
        cmd.CommandType = CommandType.Text
        cmd.Connection = connection

        cmmd.CommandText = "Select quantity FROM medicines where     name='" & input.Text() & "' And Eid = '" & id.Text() & "' "
        cmmd.CommandType = CommandType.Text
        cmmd.Connection = connection
        If cmd.ExecuteScalar <> 0 Then
            Dim str As String = cmmd.ExecuteScalar
            MessageBox.Show("Your Medicine '" & input.Text() & "' is Present with quantity of '" & str & "' in data", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.None)

        Else
            If MessageBox.Show("Invalid Combination Of name and Eid or they may be not present in the data", "Invalid Input", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Cancel Then
                Me.Close()
                Exit Sub
            Else
                id.Text = ""
                input.Text = ""
            End If
        End If
        cmd.ExecuteNonQuery()
        cmd.Dispose()
        connection.Close()



    End Sub

    

End Class