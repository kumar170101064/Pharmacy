﻿Imports System.Data.OleDb




Public Class add
    Dim provider As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
    Dim datafile As String = "C:\Users\DELL\Desktop\data.accdb"
    Dim Connstring As String = provider & datafile
    Dim connection As OleDbConnection = New OleDbConnection


    Private Sub name_TextChanged(sender As Object, e As EventArgs) Handles nam.TextChanged

    End Sub

    Private Sub rate_TextChanged(sender As Object, e As EventArgs) Handles rate.TextChanged

    End Sub

    Private Sub quantity_TextChanged(sender As Object, e As EventArgs) Handles quantity.TextChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles dat.ValueChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles add_item.Click
        Dim id As String = eid.Text()
        Dim i As Integer = 0
        If Not (Len(id) = 7) Then
            If MessageBox.Show("Eid is not Properly Defined", "Eid Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Cancel Then
                Me.Close()
            Else
                eid.Text = ""
                Exit Sub
            End If
            Exit Sub
        End If



        For i = 0 To Len(id) - 1

            If i < 3 And (Asc(id(i)) < Asc("a") Or Asc("z") < Asc(id(i))) Then
                If MessageBox.Show("Eid should contain 3 name characters", "Eid Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Cancel Then
                    Me.Close()
                    Exit Sub
                Else
                    eid.Text = ""
                    Exit Sub
                End If
            End If
            If i > 2 And (Asc(id(i)) > Asc("9") Or Asc("0") > Asc(id(i))) Then
                If MessageBox.Show("Eid should contain last 4 number characters", "Inappropriate Primary value", MessageBoxButtons.RetryCancel, MessageBoxIcon.Asterisk) = Windows.Forms.DialogResult.Cancel Then
                    Me.Close()
                    Exit Sub
                Else
                    eid.Text = ""
                    Exit Sub
                End If
            End If

        Next
       


        Dim cmd As OleDbCommand = New OleDbCommand

        connection.ConnectionString = Connstring
        connection.Open()

        Try

        Catch

        End Try


        cmd.Parameters.Add(cmd.CreateParameter).ParameterName = "name"
        cmd.Parameters.Item("name").Value = nam.Text()
        cmd.Parameters.Add(cmd.CreateParameter).ParameterName = "Eid"
        cmd.Parameters.Item("Eid").Value = eid.Text()
        cmd.Parameters.Add(cmd.CreateParameter).ParameterName = "rate"
        cmd.Parameters.Item("rate").Value = rate.Text()
        cmd.Parameters.Add(cmd.CreateParameter).ParameterName = "quantity"
        cmd.Parameters.Item("quantity").Value = quantity.Text()
        cmd.Parameters.Add(cmd.CreateParameter).ParameterName = "expiry"
        cmd.Parameters.Item("expiry").Value = dat.Text()
        Try
            cmd.CommandText = "INSERT INTO medicines (Eid,name,rate,quantity,expiry) VALUES ('" & eid.Text() & "','" & nam.Text() & "','" & rate.Text() & "','" & quantity.Text() & "','" & dat.Text() & "');"
            cmd.CommandType = CommandType.Text
            cmd.Connection = connection

            cmd.ExecuteNonQuery()
            cmd.Dispose()

            connection.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            eid.Clear()
            connection.Close()
            Exit Sub
        End Try

        MessageBox.Show("Successful Addition Of data", "Done")
        eid.Clear()
        nam.Clear()
        rate.Clear()
        quantity.Clear()
    End Sub











    



    Private Sub eid_TextChanged(sender As Object, e As EventArgs) Handles eid.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub cancel_Click(sender As Object, e As EventArgs) Handles cancel.Click
        Me.Close()
        Exit Sub
    End Sub

    Private Sub clear_Click(sender As Object, e As EventArgs) Handles clear.Click


        If MessageBox.Show("Do you Really Want to delete all data", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
            connection.ConnectionString = Connstring
            connection.Open()


            Dim cmd As OleDbCommand = New OleDbCommand
            cmd.CommandText = "DELETE *  FROM Medicines"
            cmd.CommandType = CommandType.Text
            cmd.Connection = connection


            cmd.ExecuteNonQuery()
            cmd.Dispose()
            connection.Close()

        End If
    End Sub

    Private Sub add_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class