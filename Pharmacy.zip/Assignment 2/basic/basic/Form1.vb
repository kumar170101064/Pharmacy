﻿Public Class Form1

  

    Private Sub med_MouseHover(sender As Object, e As EventArgs) Handles med.MouseHover
        strip.Show(med, 0, med.Height)
    End Sub

    Private Sub med_MouseLeave(sender As Object, e As EventArgs) Handles med.MouseLeave



    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub check_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub med_Click(sender As Object, e As EventArgs) Handles med.Click

    End Sub

    Private Sub AddElementToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddElementToolStripMenuItem.Click

        add.Show()
    End Sub

    Private Sub CheckAvailabilityToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckAvailabilityToolStripMenuItem.Click
        check.Show()
    End Sub

    Private Sub ExpiredToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles updateToolStripMenuItem.Click

        upd.Show()
    End Sub

    Private Sub ten_Click(sender As Object, e As EventArgs) Handles ten.Click







    End Sub

    Private Sub Bill_Click(sender As Object, e As EventArgs) Handles Bill.Click

    End Sub
End Class
