﻿
Imports System.Data.OleDb


Public Class upd
    Dim provider As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
    Dim datafile As String = "C:\Users\DELL\Desktop\data.accdb"
    Dim Connstring As String = provider & datafile
    Dim connection As OleDbConnection = New OleDbConnection

    Private Sub upd_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub update_Click(sender As Object, e As EventArgs) Handles upda.Click
        connection.ConnectionString = Connstring
        connection.Open()

        Dim count As Integer = quantity.Text

        Dim cmd As OleDbCommand = New OleDbCommand

        Dim cmmd As OleDbCommand = New OleDbCommand
        Dim cm As OleDbCommand = New OleDbCommand

        cmd.CommandText = "Select COUNT(*) FROM medicines where     name='" & input.Text() & "' And Eid = '" & id.Text() & "' "
        cmd.CommandType = CommandType.Text
        cmd.Connection = connection

        cmmd.CommandText = "Select quantity FROM medicines where     name='" & input.Text() & "' And Eid = '" & id.Text() & "' "
        cmmd.CommandType = CommandType.Text
        cmmd.Connection = connection
        cm.CommandText = "UPDATE   medicines SET quantity =quantity+'" & count & "' where  ( name='" & input.Text() & "' And Eid = '" & id.Text() & "' )"
        cm.CommandType = CommandType.Text
        cm.Connection = connection
        If cmd.ExecuteScalar <> 0 Then
            
            ' MessageBox.Show("Your Medicine '" & input.Text() & "' is Present with quantity of '" & count & "' in data", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.None)
            cm.ExecuteNonQuery()
            cm.Dispose()
            MessageBox.Show("Update successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.None)
        Else
            If MessageBox.Show("Invalid Combination Of name and Eid or they may be not present in the data", "Invalid Input", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) = Windows.Forms.DialogResult.Cancel Then
                Me.Close()
                Exit Sub
            Else
                id.Text = ""
                input.Text = ""
            End If
        End If
        cmd.ExecuteNonQuery()
        cmd.Dispose()
        connection.Close()



    End Sub
End Class