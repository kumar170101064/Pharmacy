﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.med = New System.Windows.Forms.Button()
        Me.strip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddElementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckAvailabilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.updateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ten = New System.Windows.Forms.Button()
        Me.Bill = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.strip.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'med
        '
        Me.med.AllowDrop = True
        Me.med.BackColor = System.Drawing.Color.IndianRed
        Me.med.ContextMenuStrip = Me.strip
        Me.med.ForeColor = System.Drawing.SystemColors.ControlText
        resources.ApplyResources(Me.med, "med")
        Me.med.Name = "med"
        Me.med.UseVisualStyleBackColor = False
        '
        'strip
        '
        Me.strip.AllowDrop = True
        Me.strip.BackColor = System.Drawing.SystemColors.ActiveCaption
        resources.ApplyResources(Me.strip, "strip")
        Me.strip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.strip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddElementToolStripMenuItem, Me.CheckAvailabilityToolStripMenuItem, Me.updateToolStripMenuItem})
        Me.strip.Name = "strip"
        Me.strip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        '
        'AddElementToolStripMenuItem
        '
        Me.AddElementToolStripMenuItem.Name = "AddElementToolStripMenuItem"
        Me.AddElementToolStripMenuItem.Padding = New System.Windows.Forms.Padding(0)
        resources.ApplyResources(Me.AddElementToolStripMenuItem, "AddElementToolStripMenuItem")
        '
        'CheckAvailabilityToolStripMenuItem
        '
        Me.CheckAvailabilityToolStripMenuItem.Name = "CheckAvailabilityToolStripMenuItem"
        resources.ApplyResources(Me.CheckAvailabilityToolStripMenuItem, "CheckAvailabilityToolStripMenuItem")
        '
        'updateToolStripMenuItem
        '
        Me.updateToolStripMenuItem.Name = "updateToolStripMenuItem"
        resources.ApplyResources(Me.updateToolStripMenuItem, "updateToolStripMenuItem")
        '
        'ten
        '
        Me.ten.BackColor = System.Drawing.Color.IndianRed
        Me.ten.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        resources.ApplyResources(Me.ten, "ten")
        Me.ten.Name = "ten"
        Me.ten.UseVisualStyleBackColor = False
        '
        'Bill
        '
        Me.Bill.BackColor = System.Drawing.Color.IndianRed
        Me.Bill.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        resources.ApplyResources(Me.Bill, "Bill")
        Me.Bill.Name = "Bill"
        Me.Bill.UseVisualStyleBackColor = False
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label1.Name = "Label1"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.basic.My.Resources.Resources._7up_logo_2014
        resources.ApplyResources(Me.PictureBox1, "PictureBox1")
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AllowDrop = True
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        resources.ApplyResources(Me, "$this")
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BackgroundImage = Global.basic.My.Resources.Resources.index
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.med)
        Me.Controls.Add(Me.Bill)
        Me.Controls.Add(Me.ten)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.SystemColors.Control
        Me.HelpButton = True
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.strip.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents med As System.Windows.Forms.Button
    Friend WithEvents ten As System.Windows.Forms.Button
    Friend WithEvents Bill As System.Windows.Forms.Button
    Friend WithEvents strip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AddElementToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckAvailabilityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents updateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox

End Class
