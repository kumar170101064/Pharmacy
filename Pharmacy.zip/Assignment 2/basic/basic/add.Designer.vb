﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class add
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.nam = New System.Windows.Forms.TextBox()
        Me.rate = New System.Windows.Forms.TextBox()
        Me.quantity = New System.Windows.Forms.TextBox()
        Me.dat = New System.Windows.Forms.DateTimePicker()
        Me.add_item = New System.Windows.Forms.Button()
        Me.eid = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Box1 = New System.Windows.Forms.GroupBox()
        Me.cancel = New System.Windows.Forms.Button()
        Me.clear = New System.Windows.Forms.Button()
        Me.Box1.SuspendLayout()
        Me.SuspendLayout()
        '
        'nam
        '
        Me.nam.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.nam.Location = New System.Drawing.Point(306, 120)
        Me.nam.Name = "nam"
        Me.nam.Size = New System.Drawing.Size(187, 22)
        Me.nam.TabIndex = 0
        '
        'rate
        '
        Me.rate.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.rate.Location = New System.Drawing.Point(306, 170)
        Me.rate.Name = "rate"
        Me.rate.Size = New System.Drawing.Size(72, 22)
        Me.rate.TabIndex = 1
        '
        'quantity
        '
        Me.quantity.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.quantity.Location = New System.Drawing.Point(306, 227)
        Me.quantity.Name = "quantity"
        Me.quantity.Size = New System.Drawing.Size(72, 22)
        Me.quantity.TabIndex = 2
        '
        'dat
        '
        Me.dat.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dat.Location = New System.Drawing.Point(306, 288)
        Me.dat.Name = "dat"
        Me.dat.Size = New System.Drawing.Size(109, 22)
        Me.dat.TabIndex = 3
        '
        'add_item
        '
        Me.add_item.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.add_item.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.add_item.Location = New System.Drawing.Point(124, 381)
        Me.add_item.Name = "add_item"
        Me.add_item.Size = New System.Drawing.Size(198, 54)
        Me.add_item.TabIndex = 4
        Me.add_item.Text = "Add into data"
        Me.add_item.UseVisualStyleBackColor = False
        '
        'eid
        '
        Me.eid.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.eid.Location = New System.Drawing.Point(306, 69)
        Me.eid.Name = "eid"
        Me.eid.Size = New System.Drawing.Size(187, 22)
        Me.eid.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(69, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 25)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Eid Number"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(27, 117)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(174, 25)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Name Of Medicine"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(248, 187)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 17)
        Me.Label3.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(30, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(165, 25)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Rate of one Piece"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(10, 235)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(200, 25)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Quantity of Medicines"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(9, 288)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(201, 25)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Select the Expiry date"
        '
        'Box1
        '
        Me.Box1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Box1.AutoSize = True
        Me.Box1.BackColor = System.Drawing.Color.SandyBrown
        Me.Box1.Controls.Add(Me.eid)
        Me.Box1.Controls.Add(Me.Label6)
        Me.Box1.Controls.Add(Me.nam)
        Me.Box1.Controls.Add(Me.Label5)
        Me.Box1.Controls.Add(Me.rate)
        Me.Box1.Controls.Add(Me.Label4)
        Me.Box1.Controls.Add(Me.quantity)
        Me.Box1.Controls.Add(Me.add_item)
        Me.Box1.Controls.Add(Me.Label2)
        Me.Box1.Controls.Add(Me.dat)
        Me.Box1.Controls.Add(Me.Label1)
        Me.Box1.Location = New System.Drawing.Point(391, 12)
        Me.Box1.Name = "Box1"
        Me.Box1.Size = New System.Drawing.Size(608, 489)
        Me.Box1.TabIndex = 12
        Me.Box1.TabStop = False
        '
        'cancel
        '
        Me.cancel.BackColor = System.Drawing.Color.Red
        Me.cancel.ForeColor = System.Drawing.Color.Black
        Me.cancel.Location = New System.Drawing.Point(1194, 12)
        Me.cancel.Name = "cancel"
        Me.cancel.Size = New System.Drawing.Size(145, 55)
        Me.cancel.TabIndex = 12
        Me.cancel.Text = "Exit"
        Me.cancel.UseVisualStyleBackColor = False
        '
        'clear
        '
        Me.clear.BackColor = System.Drawing.Color.Red
        Me.clear.Location = New System.Drawing.Point(1194, 85)
        Me.clear.Name = "clear"
        Me.clear.Size = New System.Drawing.Size(145, 44)
        Me.clear.TabIndex = 13
        Me.clear.Text = "Clear All data"
        Me.clear.UseVisualStyleBackColor = False
        '
        'add
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.basic.My.Resources.Resources.Modern_Medicine
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1351, 513)
        Me.Controls.Add(Me.clear)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.Box1)
        Me.Controls.Add(Me.Label3)
        Me.Name = "add"
        Me.Text = "check_form"
        Me.Box1.ResumeLayout(False)
        Me.Box1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents nam As System.Windows.Forms.TextBox
    Friend WithEvents rate As System.Windows.Forms.TextBox
    Friend WithEvents quantity As System.Windows.Forms.TextBox
    Friend WithEvents dat As System.Windows.Forms.DateTimePicker
    Friend WithEvents add_item As System.Windows.Forms.Button
    Friend WithEvents eid As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Box1 As System.Windows.Forms.GroupBox
    Friend WithEvents cancel As System.Windows.Forms.Button
    Friend WithEvents clear As System.Windows.Forms.Button
End Class
