﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class upd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.upda = New System.Windows.Forms.Button()
        Me.id = New System.Windows.Forms.TextBox()
        Me.input = New System.Windows.Forms.TextBox()
        Me.rate = New System.Windows.Forms.TextBox()
        Me.quantity = New System.Windows.Forms.TextBox()
        Me.pick = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'upda
        '
        Me.upda.Location = New System.Drawing.Point(166, 259)
        Me.upda.Name = "upda"
        Me.upda.Size = New System.Drawing.Size(161, 45)
        Me.upda.TabIndex = 0
        Me.upda.Text = "Update"
        Me.upda.UseVisualStyleBackColor = True
        '
        'id
        '
        Me.id.Location = New System.Drawing.Point(249, 45)
        Me.id.Name = "id"
        Me.id.Size = New System.Drawing.Size(187, 22)
        Me.id.TabIndex = 1
        '
        'input
        '
        Me.input.Location = New System.Drawing.Point(249, 87)
        Me.input.Name = "input"
        Me.input.Size = New System.Drawing.Size(249, 22)
        Me.input.TabIndex = 2
        '
        'rate
        '
        Me.rate.Location = New System.Drawing.Point(249, 125)
        Me.rate.Name = "rate"
        Me.rate.Size = New System.Drawing.Size(78, 22)
        Me.rate.TabIndex = 3
        '
        'quantity
        '
        Me.quantity.Location = New System.Drawing.Point(249, 166)
        Me.quantity.Name = "quantity"
        Me.quantity.Size = New System.Drawing.Size(78, 22)
        Me.quantity.TabIndex = 4
        '
        'pick
        '
        Me.pick.Location = New System.Drawing.Point(249, 209)
        Me.pick.Name = "pick"
        Me.pick.Size = New System.Drawing.Size(183, 22)
        Me.pick.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(146, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Eid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(129, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 17)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(136, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Rate"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(113, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 17)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Quantity"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(113, 209)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 17)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Expiry Before"
        '
        'upd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(693, 336)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.pick)
        Me.Controls.Add(Me.quantity)
        Me.Controls.Add(Me.rate)
        Me.Controls.Add(Me.input)
        Me.Controls.Add(Me.id)
        Me.Controls.Add(Me.upda)
        Me.Name = "upd"
        Me.Text = "upd"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents upda As System.Windows.Forms.Button
    Friend WithEvents id As System.Windows.Forms.TextBox
    Friend WithEvents input As System.Windows.Forms.TextBox
    Friend WithEvents rate As System.Windows.Forms.TextBox
    Friend WithEvents quantity As System.Windows.Forms.TextBox
    Friend WithEvents pick As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
End Class
