﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class test
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Medicines = New basic.medicines()
        Me.MedicinesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataDataSet = New basic.dataDataSet()
        Me.DataDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MedicinesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Medicines, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MedicinesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MedicinesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.DataSource = Me.MedicinesBindingSource1
        Me.DataGridView1.Location = New System.Drawing.Point(377, 28)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(366, 135)
        Me.DataGridView1.TabIndex = 0
        '
        'Medicines
        '
        Me.Medicines.DataSetName = "medicines"
        Me.Medicines.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MedicinesBindingSource
        '
        Me.MedicinesBindingSource.DataSource = Me.Medicines
        Me.MedicinesBindingSource.Position = 0
        '
        'DataDataSet
        '
        Me.DataDataSet.DataSetName = "dataDataSet"
        Me.DataDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataDataSetBindingSource
        '
        Me.DataDataSetBindingSource.DataSource = Me.DataDataSet
        Me.DataDataSetBindingSource.Position = 0
        '
        'MedicinesBindingSource1
        '
        Me.MedicinesBindingSource1.DataSource = Me.Medicines
        Me.MedicinesBindingSource1.Position = 0
        '
        'test
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(973, 253)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "test"
        Me.Text = "test"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Medicines, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MedicinesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MedicinesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents MedicinesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Medicines As basic.medicines
    Friend WithEvents DataDataSet As basic.dataDataSet
    Friend WithEvents DataDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MedicinesBindingSource1 As System.Windows.Forms.BindingSource
End Class
